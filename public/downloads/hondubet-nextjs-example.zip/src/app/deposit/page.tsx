import DepositDialog from "@/components/DepositDialog";

export default function DepositPage() {
  return (
    <main className="max-w-xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Depositar</h1>
      <p className="text-sm text-slate-300 mb-6">
        Demo de integración: init → widget 3DS → confirm
      </p>
      <DepositDialog />
    </main>
  );
}
