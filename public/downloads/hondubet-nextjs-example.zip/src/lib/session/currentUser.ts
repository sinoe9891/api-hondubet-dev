export const currentUser = {
  name: 'NOMBRE DE PRUEBA',
  email: 'correo@gmail.com',
  billing: {
    address: 'Dirección',
    country: 'HN',
    state: 'CM',
    city: 'Siguatepeque',
    phone: '+50431828143',
  },
} as const;
