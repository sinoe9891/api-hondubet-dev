export {};

declare global {
  interface Window {
    BMTCheckout?: {
      open: (opts: { checkoutUrl: string; onResult: (result: any) => void }) => void;
    };
  }
}
