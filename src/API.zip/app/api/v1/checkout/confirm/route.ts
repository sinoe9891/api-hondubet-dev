import { NextResponse } from "next/server";
import { getDb, doc, getDoc, updateDoc, serverTimestamp } from "@/config/firebase/api";
import { getStatusByPaymentUuid } from "@/lib/pixelpay-server";

export const runtime = "nodejs";

type PixelStatus = "approved" | "pending" | "declined";
type OrderStatus = "PAID" | "PENDING" | "FAILED";

interface ConfirmBody {
  order_id: string;
  payment_uuid?: string | null;
  payment_hash?: string | null;
}

interface PixelSaleData {
  transaction_type?: string;
  transaction_approved_amount?: number | string | null;
  transaction_amount?: number | string | null;
  response_cvn?: string | null;
  response_avs?: string | null;
  response_cavv?: string | null;
  transaction_id?: string;
  transaction_time?: string;
  transaction_date?: string;
  response_approved?: boolean;
  response_incomplete?: boolean;
  response_code?: string;
  response_time?: string;
  response_reason?: string;
  payment_uuid?: string;
  payment_hash?: string;
  transaction_state?: string;
  transaction_status?: string;
  state?: string;
}

type PixelLike = Record<string, unknown> & Partial<PixelSaleData>;

function toPlainJSON<T>(value: T): Record<string, unknown> | null {
  try {
    const parsed = JSON.parse(JSON.stringify(value)) as unknown;
    if (typeof parsed === "object" && parsed !== null) return parsed as Record<string, unknown>;
    return null;
  } catch {
    return null;
  }
}

function b(v: unknown): boolean { return v === true; }
function s(v: unknown): string { return typeof v === "string" ? v : ""; }

function isApproved(r: PixelLike): boolean {
  const state = s(r.transaction_state ?? r.transaction_status ?? r.state).toLowerCase();
  return b(r.response_approved) || s(r.response_code) === "00" || state === "approved";
}
function isPending(r: PixelLike): boolean {
  const state = s(r.transaction_state ?? r.transaction_status ?? r.state).toLowerCase();
  const reason = s(r.response_reason).toLowerCase();
  return r.response_incomplete === true || state === "pending" || reason.includes("pend");
}

function normalizePixelStatus(resp: unknown): { pixel_status: PixelStatus; raw: PixelLike | null } {
  const obj: PixelLike = (typeof resp === "object" && resp !== null ? (resp as PixelLike) : {}) as PixelLike;
  try {
    if (isApproved(obj)) return { pixel_status: "approved", raw: obj };
    if (isPending(obj))  return { pixel_status: "pending",  raw: obj };
    return { pixel_status: "declined", raw: obj };
  } catch {
    return { pixel_status: "declined", raw: obj };
  }
}

function looksLikeMd5(s: unknown): s is string {
  return typeof s === "string" && /^[a-f0-9]{32}$/i.test(s);
}

export async function POST(req: Request) {
  const url = new URL(req.url);
  const debug = url.searchParams.get("debug") === "1";
  const DBG: Record<string, unknown> = {};

  try {
    const bodyUnknown = await req.json().catch(() => null) as unknown;
    const bdy = (typeof bodyUnknown === "object" && bodyUnknown !== null ? bodyUnknown as ConfirmBody : undefined);
    const order_id = bdy?.order_id;
    const payment_uuid = bdy?.payment_uuid ?? null;
    const payment_hash = bdy?.payment_hash ?? null;

    if (!order_id) return NextResponse.json({ success:false, message:"order_id requerido" }, { status:400 });

    const db = getDb();
    const ref = doc(db, "bmt_orders", String(order_id));
    const snap = await getDoc(ref);
    if (!snap.exists) return NextResponse.json({ success:false, message:"La orden no existe" }, { status:404 });

    const order = snap.data() as Record<string, unknown> | undefined;
    DBG.orderExists = true;

    const savedHash =
      (order?.["payment_hash"] as string | undefined) ??
      ((order?.["pixelpay"] as Record<string, unknown> | undefined)?.["payment_hash"] as string | undefined) ??
      ((order?.["last_sale"] as Record<string, unknown> | undefined)?.["payment_hash"] as string | undefined) ??
      null;

    let approvedByHash = false;
    let hashReason = "";
    if (looksLikeMd5(payment_hash)) {
      if (looksLikeMd5(savedHash)) {
        approvedByHash = savedHash.toLowerCase() === payment_hash.toLowerCase();
        hashReason = approvedByHash ? "hash matches savedHash" : "hash mismatch";
      } else {
        approvedByHash = typeof payment_uuid === "string" && payment_uuid.length > 0;
        hashReason = approvedByHash ? "accepted incoming hash + payment_uuid" : "no savedHash and no payment_uuid";
      }
    } else {
      hashReason = "incoming hash not md5-looking";
    }
    DBG.approvedByHash = approvedByHash;
    DBG.hashReason = hashReason;
    DBG.savedHashPresent = !!savedHash;

    const hasServerCreds = Boolean(process.env.PIXELPAY_KEY_ID && process.env.PIXELPAY_SECRET);

    let pixel_status: PixelStatus | null = null;
    let pixel_raw: PixelLike | null = null;

    if (payment_uuid && hasServerCreds) {
      try {
        const statusResp: unknown = await getStatusByPaymentUuid(payment_uuid);
        const norm = normalizePixelStatus(statusResp);
        pixel_status = norm.pixel_status;
        pixel_raw = norm.raw;
        DBG.pixelStatusFromUuid = pixel_status;
      } catch (e) {
        pixel_status = null;
        pixel_raw = toPlainJSON({ error: true, message: e instanceof Error ? e.message : "Error al consultar estado" });
        DBG.pixelStatusError = (e instanceof Error ? e.message : "unknown");
      }
    } else {
      DBG.pixelStatusFromUuid = hasServerCreds ? "skipped (no payment_uuid)" : "skipped (no server creds)";
    }

    let status: OrderStatus = "FAILED";
    let decision = "";
    if (approvedByHash)             { status = "PAID";    decision = "approved by hash"; }
    else if (pixel_status === "approved") { status = "PAID";    decision = "approved by Pixel status"; }
    else if (pixel_status === "pending")  { status = "PENDING"; decision = "pending"; }
    else                             { status = "FAILED";  decision = "declined/no proof"; }
    DBG.decision = decision;

    const pixel_raw_plain = pixel_status === "approved" ? null : toPlainJSON(pixel_raw);

    await updateDoc(ref, {
      status,
      payment_uuid: payment_uuid ?? null,
      payment_hash: looksLikeMd5(payment_hash) ? payment_hash : null,
      pixel_status: pixel_status ?? null,
      pixel_raw: pixel_raw_plain,
      status_checked_at: serverTimestamp(),
    });

    const base = { success: true, order_id, status, pixel_status: pixel_status ?? null };
    return debug ? NextResponse.json({ ...base, debug: DBG }) : NextResponse.json(base);
  } catch (e) {
    const message = e instanceof Error ? e.message : "Error interno";
    return NextResponse.json({ success:false, message }, { status:500 });
  }
}
