import { NextRequest, NextResponse } from "next/server";
import { getDb, doc, getDoc, updateDoc } from "@/config/firebase/api";

export const runtime = "nodejs";

type PixelCheck = {
  success?: boolean;
  message?: string;
  data?: {
    response_approved?: boolean;
    response_code?: string;
    response_reason?: string;
    payment_uuid?: string|null;
    payment_hash?: string|null;
    [k: string]: unknown;
  };
  [k: string]: unknown;
};

function mapHttpToStatus(http: number, approved: boolean): "PAID"|"DECLINED"|"PENDING"|"ERROR" {
  if (http === 200) return approved ? "PAID" : "DECLINED";
  if (http === 402) return "DECLINED";
  if (http === 408) return "PENDING";
  if (http === 401 || http === 403) return "ERROR";
  if (http === 404 || http === 405 || http === 406) return "ERROR";
  if (http === 412 || http === 418 || http === 422) return "ERROR";
  if (http >= 500) return "ERROR";
  return "ERROR";
}

type Params = { orderId: string };
function isPromise<T>(v: unknown): v is Promise<T> {
  return typeof (v as { then?: unknown })?.then === "function";
}

export async function POST(
  req: NextRequest,
  ctx: { params: Params } | { params: Promise<Params> }
) {
  const p = isPromise<Params>((ctx as { params: unknown }).params)
    ? await (ctx as { params: Promise<Params> }).params
    : (ctx as { params: Params }).params;

  const { orderId } = p;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const payment_uuid = (body.payment_uuid ?? null) as string | null;
  const payment_hash = (body.payment_hash ?? null) as string | null;

  // 1) Recupera orden
  const db = getDb();
  const ref = doc(db, "bmt_orders", orderId);
  const snap = await getDoc(ref);
  if (!snap.exists) {
    return NextResponse.json({ success:false, message:"Orden no existe" }, { status: 404 });
  }

  // 2) Llama a tu proxy /api/pixelpay para verificar estado en el gateway
  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  const qs = new URLSearchParams();
  if (payment_uuid) qs.set("uuid", String(payment_uuid));
  if (payment_hash) qs.set("hash", String(payment_hash));

  const statusUrl = `${base}/api/pixelpay/transaction/status?${qs.toString()}`;
  const upstream = await fetch(statusUrl, {
    method: "GET",
    headers: { "content-type": "application/json" },
    cache: "no-store",
  }).catch((e) => {
    // Falla de red hacia el proxy o el proxy hacia upstream
    return new Response(JSON.stringify({ message: String(e?.message || e) }), { status: 502 });
  });

  const httpCode = upstream.status;
  const raw = (await upstream.json().catch(() => ({}))) as PixelCheck;

  const approved =
    Boolean(raw?.data?.response_approved) ||
    Boolean((raw as Record<string, unknown>)?.response_approved);

  const status = mapHttpToStatus(httpCode, approved);

  // 3) Guarda TODO crudo para auditoría
  await updateDoc(ref, {
    pixel_status: approved ? "APPROVED" : "DECLINED",
    pixel_raw: raw,
    payment_uuid: raw?.data?.payment_uuid ?? payment_uuid ?? null,
    payment_hash: raw?.data?.payment_hash ?? payment_hash ?? null,
    status, // PAID / DECLINED / PENDING / ERROR
    status_checked_at: new Date(),
  });

  return NextResponse.json({
    success: true,
    status,
    approved,
    code: raw?.data?.response_code ?? null,
    reason: raw?.data?.response_reason ?? null,
    message: raw?.message ?? null,
  });
}
